package br.maua.interfaces;

public interface Walk {
    String walk(int distance);
}
