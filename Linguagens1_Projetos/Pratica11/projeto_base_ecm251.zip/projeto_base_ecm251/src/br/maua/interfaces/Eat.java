package br.maua.interfaces;

public interface Eat {
    String eat(int amount);
}
