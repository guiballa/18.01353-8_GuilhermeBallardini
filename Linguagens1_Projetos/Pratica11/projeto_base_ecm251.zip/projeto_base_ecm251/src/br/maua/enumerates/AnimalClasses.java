package br.maua.enumerates;

public enum AnimalClasses {
    DOMESTIC, WILD, CIRCUS;
}
